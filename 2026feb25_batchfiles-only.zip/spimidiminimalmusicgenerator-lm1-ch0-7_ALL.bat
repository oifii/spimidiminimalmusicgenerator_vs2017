rem parameters are: octave midichannel
rem octave is a value between -1 to 9, use octave -2 to specify all octaves
rem valid midichannel is 
rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" 3 0
rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" 3 1
rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" 3 2
rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" 3 3
rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" 3 4
rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" 3 5
rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" 3 6
rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" 3 7

rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" -2 0
rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" -2 1
rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" -2 2
rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" -2 3
rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" -2 4
rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" -2 5
rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" -2 6
rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" -2 7

rem start"" "spimidiminimalmusicgenerator-lm1-ch0_C.bat"
rem start"" "spimidiminimalmusicgenerator-lm1-ch1_C.bat" 
rem start"" "spimidiminimalmusicgenerator-lm1-ch2_C.bat" 
rem start"" "spimidiminimalmusicgenerator-lm1-ch3_C.bat" 
rem start"" "spimidiminimalmusicgenerator-lm1-ch4_C.bat" 
rem start"" "spimidiminimalmusicgenerator-lm1-ch5_C.bat" 
rem start"" "spimidiminimalmusicgenerator-lm1-ch6_C.bat" 
rem start"" "spimidiminimalmusicgenerator-lm1-ch7_C.bat" 

start "" "spimidiminimalmusicgenerator-lm1-ch0_ALL.bat"
start "" "spimidiminimalmusicgenerator-lm1-ch1_ALL.bat" 
start "" "spimidiminimalmusicgenerator-lm1-ch2_ALL.bat" 
start "" "spimidiminimalmusicgenerator-lm1-ch3_ALL.bat" 
start "" "spimidiminimalmusicgenerator-lm1-ch4_ALL.bat" 
start "" "spimidiminimalmusicgenerator-lm1-ch5_ALL.bat" 
start "" "spimidiminimalmusicgenerator-lm1-ch6_ALL.bat" 
start "" "spimidiminimalmusicgenerator-lm1-ch7_ALL.bat" 