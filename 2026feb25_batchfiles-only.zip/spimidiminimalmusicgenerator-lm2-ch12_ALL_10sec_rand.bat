rem start spimidiminimalmusicgenerator.exe "C3,D3,E3,F3,G3,A3,B3" 2.0 300.0 "loopMIDI Port 1" 0 2 2
rem start spimidiminimalmusicgenerator.exe "C2,D2,E2,F2,G2,A2,B2" 2.0 300.0 "loopMIDI Port 1" 1 1 2
rem start spimidiminimalmusicgenerator.exe "C1,D1,E1,F1,G1,A1,B1,C2,D2,E2,F2,G2,A2,B2" 2.0 300.0 "loopMIDI Port 1" 2 2 2
rem
rem 2020sept27
echo off
setlocal enabledelayedexpansion enableextensions
set noteset=%1%
if [%1%] == [] (
	rem noteset can be a note, i.e. to get the "C" of all octaves
	rem set noteset="C"
	set noteset="ALL"
	rem noteset can be an octave, to get notes of one octave between -1 to 9, use noteset "-2" or "ALL" to get all notes from all octaves
	rem set noteset="-2"
	rem set noteset="3"
	rem set noteset="-2"
)
set midichannel=%2%
if [%2%] == [] (
	set midichannel=12
)
rem octave can be between -1 to 9, use octave -2 to specify all octaves
rem midichannel can be between 0 and 15
rem 
rem if %octave%=="C
rem set /a octnum = %octave% + 0
rem echo octnum is %octnum%
rem set /a minustwo = -2
rem if %octnum% EQU %minustwo% (
rem set noteset="ALL"
rem ) else (
rem set noteset=%octnum%
rem )
rem set noteset="%noteset:"=%"
rem set noteset="C3,C#3,D3,D#3,E3,F3,F#3,G3,G#3,A3,A#3,B3"
rem set /a notechangeperiod_s = 1
rem set notechangeperiod_s=1
rem set notechangeperiod_s=0.5
rem set notechangeperiod_s=0.25
rem set notechangeperiod_s=0.125
set notechangeperiod_s=10
rem set /a global_loopduration_s = -1
set /a global_loopduration_s = 3600
set midioutputdevicename="loopMIDI Port 2"
rem set /a outputmidichannel = 0
set /a outputmidichannel = %midichannel:"=%
set /a numberofsimultaneousnotes = 2
set /a numberofnotesonchange = 1
rem set modestring="SEQUENTIAL"
set modestring="RANDOM"
echo on
start spimidiminimalmusicgenerator.exe %noteset% %notechangeperiod_s% %global_loopduration_s% %midioutputdevicename% %outputmidichannel% %numberofsimultaneousnotes% %numberofnotesonchange% %modestring%
rem start spimidiminimalmusicgenerator.exe %noteset% 0.25 %global_loopduration_s% %midioutputdevicename% %outputmidichannel% %numberofsimultaneousnotes% %numberofnotesonchange% %modestring%
echo spimidiminimalmusicgenerator.exe %noteset% %notechangeperiod_s% %global_loopduration_s% %midioutputdevicename% %outputmidichannel% %numberofsimultaneousnotes% %numberofnotesonchange% %modestring%
rem pause
exit

:notesetoneoctave
set c=C
set cs=C#
set d=D
set ds=D#
set e=E
set f=F
set fs=F#
set g=G
set gs=G#
set a=A
set as=A#
set b=B
set coma=,
set noteset="%c%%octave%%coma%%cs%%octave%%coma%%d%%octave%%coma%%ds%%octave%%coma%%e%%octave%%coma%%f%%octave%%coma%%fs%%octave%%coma%%g%%octave%%coma%%gs%%octave%%coma%%a%%octave%%coma%%as%%octave%%coma%%b%%octave%%coma%"
EXIT /B 0

:notesetalloctavestest
set c=C
set cs=C#
set d=D
set ds=D#
set e=E
set f=F
set fs=F#
set g=G
set gs=G#
set a=A
set as=A#
set b=B
set coma=,
set noteset=""
for /l %%i in (-2,1,8) do ( 
echo %%i
set octave=%%i
set newnoteset="%c%%octave%%coma%%cs%%octave%%coma%%d%%octave%%coma%%ds%%octave%%coma%%e%%octave%%coma%%f%%octave%%coma%%fs%%octave%%coma%%g%%octave%%coma%%gs%%octave%%coma%%a%%octave%%coma%%as%%octave%%coma%%b%%octave%%coma%"
set noteset=%noteset%%newnoteset%
)
EXIT /B 0

:notesetalloctaves
set c=C
set cs=C#
set d=D
set ds=D#
set e=E
set f=F
set fs=F#
set g=G
set gs=G#
set a=A
set as=A#
set b=B
set coma=,
set noteset=""
for /L %%i in (1,1,9) do ( 
	set /a octave = %%i
	rem set octave="2"
	set newnoteset="%c%%octave%%coma%%cs%%octave%%coma%%d%%octave%%coma%%ds%%octave%%coma%%e%%octave%%coma%%f%%octave%%coma%%fs%%octave%%coma%%g%%octave%%coma%%gs%%octave%%coma%%a%%octave%%coma%%as%%octave%%coma%%b%%octave%%coma%"
	set noteset=%noteset%%newnoteset%
)
EXIT /B 0