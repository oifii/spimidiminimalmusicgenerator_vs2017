rem start spimidiminimalmusicgenerator.exe "C3,D3,E3,F3,G3,A3,B3" 2.0 300.0 "loopMIDI Port 1" 0 2 2
rem start spimidiminimalmusicgenerator.exe "C2,D2,E2,F2,G2,A2,B2" 2.0 300.0 "loopMIDI Port 1" 1 1 2
rem start spimidiminimalmusicgenerator.exe "C1,D1,E1,F1,G1,A1,B1,C2,D2,E2,F2,G2,A2,B2" 2.0 300.0 "loopMIDI Port 1" 2 2 2
rem
rem 2020sept27
echo off
setlocal enabledelayedexpansion enableextensions
set octave=%1%
if [%1%] == [] (
	rem set octave="3"
	set octave="-2"
)
set midichannel=%2%
if [%2%] == [] (
	set midichannel=0
)
rem octave can be between -1 to 9, use octave -2 to specify all octaves
rem midichannel can be between 0 and 15
rem 
set c=C
set cs=C#
set d=D
set ds=D#
set e=E
set f=F
set fs=F#
set g=G
set gs=G#
set a=A
set as=A#
set b=B
set coma=,
rem set c="C"
rem set cs="C#"
rem set d="D"
rem set ds="D#"
rem set e="E"
rem set f="F"
rem set fs="F#"
rem set g="G"
rem set gs="G#"
rem set a="A"
rem set as="A#"
rem set b="B"
rem set coma=","
rem set /a param = %1% + 0
set /a octnum = %octave% + 0
echo octnum is %octnum%
rem set /a octplustwo=%octave% + 2
set /a minustwo = -2
rem if /I "%param%" EQU "-2" (
rem if [%octnum%] EQU [%minustwo%] (
rem if %octplustwo%==0 ( call notesetalloctaves )
rem else ( set noteset="%c%%octave%%coma%%cs%%octave%%coma%%d%%octave%%coma%%ds%%octave%%coma%%e%%octave%%coma%%f%%octave%%coma%%fs%%octave%%coma%%g%%octave%%coma%%gs%%octave%%coma%%a%%octave%%coma%%as%%octave%%coma%%b%%octave%%coma%" )
if %octnum% EQU %minustwo% (
call :notesetalloctavestest
) else (
rem set noteset="%c%%octave%%coma%%cs%%octave%%coma%%d%%octave%%coma%%ds%%octave%%coma%%e%%octave%%coma%%f%%octave%%coma%%fs%%octave%%coma%%g%%octave%%coma%%gs%%octave%%coma%%a%%octave%%coma%%as%%octave%%coma%%b%%octave%%coma%"
call :notesetoneoctave
)
set noteset="%noteset:"=%"
rem set noteset="%c%%octave%%coma%%cs%%octave%%coma%%d%%octave%%coma%%ds%%octave%%coma%%e%%octave%%coma%%f%%octave%%coma%%fs%%octave%%coma%%g%%octave%%coma%%gs%%octave%%coma%%a%%octave%%coma%%as%%octave%%coma%%b%%octave%%coma%"
rem set noteset="%noteset:"=%"
rem set noteset="C3,C#3,D3,D#3,E3,F3,F#3,G3,G#3,A3,A#3,B3"
set /a notechangeperiod_s = 1
rem set /a global_loopduration_s = -1
set /a global_loopduration_s = 3600
set midioutputdevicename="loopMIDI Port 1"
rem set /a outputmidichannel = 0
set /a outputmidichannel = %midichannel:"=%
set /a numberofsimultaneousnotes = 1
set /a numberofnotesonchange = 1
set modestring="SEQUENTIAL"
rem set modestring="RANDOM"
echo on
start spimidiminimalmusicgenerator.exe %noteset% %notechangeperiod_s% %global_loopduration_s% %midioutputdevicename% %outputmidichannel% %numberofsimultaneousnotes% %numberofnotesonchange% %modestring%
echo spimidiminimalmusicgenerator.exe %noteset% %notechangeperiod_s% %global_loopduration_s% %midioutputdevicename% %outputmidichannel% %numberofsimultaneousnotes% %numberofnotesonchange% %modestring%
pause
exit

:notesetoneoctave
set c=C
set cs=C#
set d=D
set ds=D#
set e=E
set f=F
set fs=F#
set g=G
set gs=G#
set a=A
set as=A#
set b=B
set coma=,
set noteset="%c%%octave%%coma%%cs%%octave%%coma%%d%%octave%%coma%%ds%%octave%%coma%%e%%octave%%coma%%f%%octave%%coma%%fs%%octave%%coma%%g%%octave%%coma%%gs%%octave%%coma%%a%%octave%%coma%%as%%octave%%coma%%b%%octave%%coma%"
EXIT /B 0

:notesetalloctavestest
set c=C
set cs=C#
set d=D
set ds=D#
set e=E
set f=F
set fs=F#
set g=G
set gs=G#
set a=A
set as=A#
set b=B
set coma=,
set noteset=""
for /l %%i in (-2,1,8) do ( 
echo %%i
set octave=%%i
set newnoteset="%c%%octave%%coma%%cs%%octave%%coma%%d%%octave%%coma%%ds%%octave%%coma%%e%%octave%%coma%%f%%octave%%coma%%fs%%octave%%coma%%g%%octave%%coma%%gs%%octave%%coma%%a%%octave%%coma%%as%%octave%%coma%%b%%octave%%coma%"
set noteset=%noteset%%newnoteset%
)
EXIT /B 0

:notesetalloctaves
set c=C
set cs=C#
set d=D
set ds=D#
set e=E
set f=F
set fs=F#
set g=G
set gs=G#
set a=A
set as=A#
set b=B
set coma=,
set noteset=""
for /L %%i in (1,1,9) do ( 
	set /a octave = %%i
	rem set octave="2"
	set newnoteset="%c%%octave%%coma%%cs%%octave%%coma%%d%%octave%%coma%%ds%%octave%%coma%%e%%octave%%coma%%f%%octave%%coma%%fs%%octave%%coma%%g%%octave%%coma%%gs%%octave%%coma%%a%%octave%%coma%%as%%octave%%coma%%b%%octave%%coma%"
	set noteset=%noteset%%newnoteset%
)
EXIT /B 0