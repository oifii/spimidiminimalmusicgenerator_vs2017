rem start spimidiminimalmusicgenerator.exe "C3,D3,E3,F3,G3,A3,B3" 2.0 300.0 "Out To MIDI Yoke:  1" 5 2
rem start spimidiminimalmusicgenerator.exe "C2,D2,E2,F2,G2,A2,B2" 2.0 300.0 "Out To MIDI Yoke:  2" 1 1
rem start spimidiminimalmusicgenerator.exe "C1,D1,E1,F1,G1,A1,B1,C2,D2,E2,F2,G2,A2,B2" 2.0 300.0 "Out To MIDI Yoke:  3" 1 2
rem start spimidiminimalmusicgenerator.exe "C3,D3,E3,F3,G3,A3,B3" 2.0 300.0 "loopMIDI Port 1" 0 2
rem start spimidiminimalmusicgenerator.exe "C2,D2,E2,F2,G2,A2,B2" 2.0 300.0 "loopMIDI Port 1" 1 1
rem start spimidiminimalmusicgenerator.exe "C1,D1,E1,F1,G1,A1,B1,C2,D2,E2,F2,G2,A2,B2" 2.0 300.0 "loopMIDI Port 1" 2 2
rem
rem 2020sept28
start "" "spimidiminimalmusicgenerator-lm1-ch0_ALL.bat"
start "" "spimidiminimalmusicgenerator-lm1-ch1_ALL.bat" 
start "" "spimidiminimalmusicgenerator-lm1-ch2_ALL.bat" 
start "" "spimidiminimalmusicgenerator-lm1-ch3_ALL.bat" 
rem start "" "spimidiminimalmusicgenerator-lm1-ch4_ALL.bat" 
rem start "" "spimidiminimalmusicgenerator-lm1-ch5_ALL.bat" 
rem start "" "spimidiminimalmusicgenerator-lm1-ch6_ALL.bat" 
rem start "" "spimidiminimalmusicgenerator-lm1-ch7_ALL.bat" 