rem parameters are: octave midichannel
rem octave is a value between -1 to 9, use octave -2 to specify all octaves
rem valid midichannel is 
rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" 3 0
rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" 3 1
rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" 3 2
rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" 3 3
rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" 3 4
rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" 3 5
rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" 3 6
rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" 3 7

rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" -2 0
rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" -2 1
rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" -2 2
rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" -2 3
rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" -2 4
rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" -2 5
rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" -2 6
rem start "" "spimidiminimalmusicgenerator-lm1-ch0.bat" -2 7

rem start"" "spimidiminimalmusicgenerator-lm1-ch0_C.bat"
rem start"" "spimidiminimalmusicgenerator-lm1-ch1_C.bat" 
rem start"" "spimidiminimalmusicgenerator-lm1-ch2_C.bat" 
rem start"" "spimidiminimalmusicgenerator-lm1-ch3_C.bat" 
rem start"" "spimidiminimalmusicgenerator-lm1-ch4_C.bat" 
rem start"" "spimidiminimalmusicgenerator-lm1-ch5_C.bat" 
rem start"" "spimidiminimalmusicgenerator-lm1-ch6_C.bat" 
rem start"" "spimidiminimalmusicgenerator-lm1-ch7_C.bat" 

setlocal EnableDelayedExpansion
start "" "spimidiminimalmusicgenerator-lm2-ch0_ALL_10sec_rand.bat"
call :delay_random
start "" "spimidiminimalmusicgenerator-lm2-ch1_ALL_10sec_rand.bat" 
call :delay_random
start "" "spimidiminimalmusicgenerator-lm2-ch2_ALL_10sec_rand.bat" 
call :delay_random
start "" "spimidiminimalmusicgenerator-lm2-ch3_ALL_10sec_rand.bat" 
call :delay_random
start "" "spimidiminimalmusicgenerator-lm2-ch4_ALL_10sec_rand.bat" 
call :delay_random
start "" "spimidiminimalmusicgenerator-lm2-ch5_ALL_10sec_rand.bat" 
call :delay_random
start "" "spimidiminimalmusicgenerator-lm2-ch6_ALL_10sec_rand.bat" 
call :delay_random
start "" "spimidiminimalmusicgenerator-lm2-ch7_ALL_10sec_rand.bat" 
call :delay_random
start "" "spimidiminimalmusicgenerator-lm2-ch8_ALL_10sec_rand.bat"
call :delay_random
start "" "spimidiminimalmusicgenerator-lm2-ch9_ALL_10sec_rand.bat" 
call :delay_random
start "" "spimidiminimalmusicgenerator-lm2-ch10_ALL_10sec_rand.bat" 
call :delay_random
start "" "spimidiminimalmusicgenerator-lm2-ch11_ALL_10sec_rand.bat" 
call :delay_random
start "" "spimidiminimalmusicgenerator-lm2-ch12_ALL_10sec_rand.bat" 
call :delay_random
start "" "spimidiminimalmusicgenerator-lm2-ch13_ALL_10sec_rand.bat" 
call :delay_random
start "" "spimidiminimalmusicgenerator-lm2-ch14_ALL_10sec_rand.bat" 
call :delay_random
start "" "spimidiminimalmusicgenerator-lm2-ch15_ALL_10sec_rand.bat" 
exit

:delay_random
set /a min = 0
set /a max = 10
rem get a number between %min% and %max%
SET /a delay_s = %RANDOM% * %max% / 32768 + %min%
echo "sleeping %delay_s%"
sleep %delay_s%
exit /b